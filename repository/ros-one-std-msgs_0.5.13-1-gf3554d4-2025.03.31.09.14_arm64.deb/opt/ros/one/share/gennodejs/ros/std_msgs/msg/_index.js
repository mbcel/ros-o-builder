
"use strict";

let Float64MultiArray = require('./Float64MultiArray.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let UInt32 = require('./UInt32.js');
let Char = require('./Char.js');
let Int16 = require('./Int16.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let String = require('./String.js');
let UInt64 = require('./UInt64.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let Float32 = require('./Float32.js');
let Header = require('./Header.js');
let Bool = require('./Bool.js');
let Float64 = require('./Float64.js');
let UInt16 = require('./UInt16.js');
let Byte = require('./Byte.js');
let ColorRGBA = require('./ColorRGBA.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let UInt8 = require('./UInt8.js');
let Int8 = require('./Int8.js');
let Duration = require('./Duration.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Int64 = require('./Int64.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int32 = require('./Int32.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let Empty = require('./Empty.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let Time = require('./Time.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');

module.exports = {
  Float64MultiArray: Float64MultiArray,
  ByteMultiArray: ByteMultiArray,
  UInt32: UInt32,
  Char: Char,
  Int16: Int16,
  MultiArrayLayout: MultiArrayLayout,
  Int8MultiArray: Int8MultiArray,
  String: String,
  UInt64: UInt64,
  UInt16MultiArray: UInt16MultiArray,
  Float32: Float32,
  Header: Header,
  Bool: Bool,
  Float64: Float64,
  UInt16: UInt16,
  Byte: Byte,
  ColorRGBA: ColorRGBA,
  Int32MultiArray: Int32MultiArray,
  UInt8: UInt8,
  Int8: Int8,
  Duration: Duration,
  Int16MultiArray: Int16MultiArray,
  UInt64MultiArray: UInt64MultiArray,
  MultiArrayDimension: MultiArrayDimension,
  Int64: Int64,
  UInt8MultiArray: UInt8MultiArray,
  Int32: Int32,
  Int64MultiArray: Int64MultiArray,
  Empty: Empty,
  Float32MultiArray: Float32MultiArray,
  Time: Time,
  UInt32MultiArray: UInt32MultiArray,
};
