
"use strict";

let FluidPressure = require('./FluidPressure.js');
let JoyFeedback = require('./JoyFeedback.js');
let TimeReference = require('./TimeReference.js');
let Temperature = require('./Temperature.js');
let CompressedImage = require('./CompressedImage.js');
let CameraInfo = require('./CameraInfo.js');
let Imu = require('./Imu.js');
let JointState = require('./JointState.js');
let LaserScan = require('./LaserScan.js');
let PointField = require('./PointField.js');
let Joy = require('./Joy.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let BatteryState = require('./BatteryState.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let LaserEcho = require('./LaserEcho.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let MagneticField = require('./MagneticField.js');
let Range = require('./Range.js');
let NavSatStatus = require('./NavSatStatus.js');
let Illuminance = require('./Illuminance.js');
let Image = require('./Image.js');
let PointCloud2 = require('./PointCloud2.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let NavSatFix = require('./NavSatFix.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let PointCloud = require('./PointCloud.js');

module.exports = {
  FluidPressure: FluidPressure,
  JoyFeedback: JoyFeedback,
  TimeReference: TimeReference,
  Temperature: Temperature,
  CompressedImage: CompressedImage,
  CameraInfo: CameraInfo,
  Imu: Imu,
  JointState: JointState,
  LaserScan: LaserScan,
  PointField: PointField,
  Joy: Joy,
  RegionOfInterest: RegionOfInterest,
  BatteryState: BatteryState,
  JoyFeedbackArray: JoyFeedbackArray,
  LaserEcho: LaserEcho,
  MultiDOFJointState: MultiDOFJointState,
  MagneticField: MagneticField,
  Range: Range,
  NavSatStatus: NavSatStatus,
  Illuminance: Illuminance,
  Image: Image,
  PointCloud2: PointCloud2,
  MultiEchoLaserScan: MultiEchoLaserScan,
  RelativeHumidity: RelativeHumidity,
  NavSatFix: NavSatFix,
  ChannelFloat32: ChannelFloat32,
  PointCloud: PointCloud,
};
