
"use strict";

let TestResult = require('./TestResult.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestAction = require('./TestAction.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestActionResult = require('./TestActionResult.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestFeedback = require('./TestFeedback.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');

module.exports = {
  TestResult: TestResult,
  TestRequestGoal: TestRequestGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsResult: TwoIntsResult,
  TestAction: TestAction,
  TestRequestResult: TestRequestResult,
  TestActionResult: TestActionResult,
  TestActionFeedback: TestActionFeedback,
  TestRequestFeedback: TestRequestFeedback,
  TestActionGoal: TestActionGoal,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsFeedback: TwoIntsFeedback,
  TestGoal: TestGoal,
  TwoIntsGoal: TwoIntsGoal,
  TwoIntsAction: TwoIntsAction,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestFeedback: TestFeedback,
  TestRequestAction: TestRequestAction,
  TestRequestActionResult: TestRequestActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
};
