
"use strict";

let TestActionFeedback = require('./TestActionFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestResult = require('./TestResult.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestAction = require('./TestAction.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestAction = require('./TestRequestAction.js');

module.exports = {
  TestActionFeedback: TestActionFeedback,
  TestActionResult: TestActionResult,
  TwoIntsGoal: TwoIntsGoal,
  TestRequestActionResult: TestRequestActionResult,
  TestRequestGoal: TestRequestGoal,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestRequestFeedback: TestRequestFeedback,
  TestResult: TestResult,
  TestGoal: TestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestFeedback: TestFeedback,
  TwoIntsResult: TwoIntsResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestResult: TestRequestResult,
  TwoIntsAction: TwoIntsAction,
  TestActionGoal: TestActionGoal,
  TestAction: TestAction,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestAction: TestRequestAction,
};
