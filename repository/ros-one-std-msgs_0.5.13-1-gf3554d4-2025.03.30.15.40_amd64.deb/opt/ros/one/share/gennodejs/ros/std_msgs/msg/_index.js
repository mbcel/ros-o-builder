
"use strict";

let MultiArrayDimension = require('./MultiArrayDimension.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Bool = require('./Bool.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Byte = require('./Byte.js');
let Header = require('./Header.js');
let ColorRGBA = require('./ColorRGBA.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let UInt32 = require('./UInt32.js');
let Char = require('./Char.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let Float32 = require('./Float32.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let Empty = require('./Empty.js');
let Int8 = require('./Int8.js');
let Time = require('./Time.js');
let Float64 = require('./Float64.js');
let UInt8 = require('./UInt8.js');
let UInt64 = require('./UInt64.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Duration = require('./Duration.js');
let Int64 = require('./Int64.js');
let UInt16 = require('./UInt16.js');
let String = require('./String.js');
let Int32 = require('./Int32.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Int16 = require('./Int16.js');
let Float32MultiArray = require('./Float32MultiArray.js');

module.exports = {
  MultiArrayDimension: MultiArrayDimension,
  Int32MultiArray: Int32MultiArray,
  Bool: Bool,
  UInt64MultiArray: UInt64MultiArray,
  UInt8MultiArray: UInt8MultiArray,
  Int16MultiArray: Int16MultiArray,
  Byte: Byte,
  Header: Header,
  ColorRGBA: ColorRGBA,
  MultiArrayLayout: MultiArrayLayout,
  UInt32: UInt32,
  Char: Char,
  UInt16MultiArray: UInt16MultiArray,
  Int64MultiArray: Int64MultiArray,
  Float32: Float32,
  ByteMultiArray: ByteMultiArray,
  Empty: Empty,
  Int8: Int8,
  Time: Time,
  Float64: Float64,
  UInt8: UInt8,
  UInt64: UInt64,
  UInt32MultiArray: UInt32MultiArray,
  Duration: Duration,
  Int64: Int64,
  UInt16: UInt16,
  String: String,
  Int32: Int32,
  Int8MultiArray: Int8MultiArray,
  Float64MultiArray: Float64MultiArray,
  Int16: Int16,
  Float32MultiArray: Float32MultiArray,
};
